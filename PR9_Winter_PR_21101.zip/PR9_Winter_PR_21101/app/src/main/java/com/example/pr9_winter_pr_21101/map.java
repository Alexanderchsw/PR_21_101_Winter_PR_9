package com.example.pr9_winter_pr_21101;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class map extends AppCompatActivity implements View.OnClickListener{
    ImageView imageView12;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);

        imageView12 = findViewById(R.id.imageView12);
        imageView12.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        Intent intent = new Intent(this, steps.class);
        startActivity(intent);
    }
}